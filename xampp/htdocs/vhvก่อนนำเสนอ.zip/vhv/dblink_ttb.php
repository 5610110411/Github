<?php
$link = @mysqli_connect("localhost", "root", "", "ttb")
				 or die(mysqli_connect_error());
?>