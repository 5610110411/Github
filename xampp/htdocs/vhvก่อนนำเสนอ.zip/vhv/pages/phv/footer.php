<?php
    echo"
    <style>
      footer {
        font-size: 14px;
      }
    </style>
    
    <footer class='panel-footer'>
    <div class='container'>
      <div class='col-xs-8 col-sm-8 col-md-8'>
        
        <p><!--a href='http://www.kohsamuicity.go.th/frontpage'-->งานสถิติข้อมูลและสารสนเทศ ฝ่ายบริการและเผยแพร่วิชาการ <!--/a-->กองวิชาการและแผนงาน เทศบาลนครเกาะสมุย</p>
        <p>มีปัญหาการใช้งานติดต่อ: 097-3518111, 077-421421-2 ต่อ 191,192 Fax ต่อ 153 Email: info@kohsamuicity.go.th</p>
        
        <!--p>Based on <a href='https://getbootstrap.com' rel='nofollow'>Bootstrap</a>. Icons from <a href='https://fortawesome.github.io/Font-Awesome/' rel='nofollow'>Font Awesome</a>. Web fonts from <a href='https://www.google.com/webfonts' rel='nofollow'>Google</a>.</p--> 
      </div>
      <div class='col-xs-4 col-sm-4 col-md-4'>
        <ul class='list-unstyled'>
          <li class='pull-right'><a href='#top'><span class='glyphicon glyphicon-menu-up'></span> Back to top</a></li>
        </ul>
      </div>
    </div>
  </footer>
  ";
?>


