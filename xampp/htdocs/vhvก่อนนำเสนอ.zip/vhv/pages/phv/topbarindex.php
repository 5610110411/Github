<?php echo "<nav class='navbar navbar-inverse'>
    <div class='container'>
      <div class='navbar-header'>
        <img src='pages/pictures/mainLogo.png' class='img-circle' alt='Cinque Terre' width='65' height='65'>
        <a class='navbar-brand' href='http://www.kohsamuicity.go.th/frontpage'>เทศบาลนครเกาะสมุย</a>
      </div>
      <ul class='nav navbar-nav'>
        <li><a href='http://www.kohsamuicity.go.th/frontpage'>หน้าหลัก</a></li>
        <li><a href='home.php'>GIS อสม.</a></li>
        <li><a href='home.php'>GIS รพ. 10,000 เตียง</a></li>
      </ul>
    </div>
  </nav>
";
?>