<?php
$link = @mysqli_connect("localhost", "root", "", "vhv")
				 or die(mysqli_connect_error());
?>